//
//  LoginForm.m
//  product_management
//
//  Created by Ty Votey on 6/17/14.
//  Copyright (c) 2014 Ty Votey. All rights reserved.
//

#import "LoginForm.h"
#import "Home.h"
#import "APIClientIOS.h"

@interface LoginForm (){
    APIClientIOS * apicleint;

}

@end

@implementation LoginForm

@synthesize txtEmail;
@synthesize txtPwd;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    apicleint = [[APIClientIOS alloc] init];
    apicleint = [APIClientIOS sharedClient];
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)btnLogin:(id)sender {
    
    NSString * userEmail = txtEmail.text;
    NSString * userPwd = txtPwd.text;
    if ([userEmail isEqualToString:@""])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Please Enter your email!", @"") message:NSLocalizedString(@"EX: abc@gmail.com", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"") otherButtonTitles: nil, nil];
        [alert show];
    }
    else   if ([userPwd isEqualToString:@""])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Please Enter your Password!", @"") message:nil delegate:self cancelButtonTitle:NSLocalizedString(@"Cancel", @"") otherButtonTitles: nil, nil];
        [alert show];
    }
    else
    {
        Home * obj = [[Home alloc] init];
        [self.navigationController pushViewController:obj animated:YES];
        
        [apicleint.requestSerializer setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        [apicleint.requestSerializer setValue:@"123" forHTTPHeaderField:@"apikey"];
        
        NSDictionary * params = @{@"email": userEmail, @"password":userPwd};
        
        [apicleint GET:@"users.json" parameters:params success:^(NSURLSessionDataTask *task, id responseObject) {
            
            
        } failure:^(NSURLSessionDataTask *task, NSError *error) {
            
            
        }];
        
    }
    

}

- (IBAction)btnForgetpwd:(id)sender {
}
@end
